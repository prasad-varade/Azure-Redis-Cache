﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Globalization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SampleRedis.Models;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using StackExchange.Redis;
using System.Diagnostics;


namespace SampleRedis.Controllers
{
    public class RedisController : Controller
    {
        public testEmployeeEntities context =new testEmployeeEntities();

        public static Lazy<ConnectionMultiplexer> lazyConnection = new Lazy<ConnectionMultiplexer>(() => {
            return ConnectionMultiplexer.Connect("testCacheEndPoint,ssl=true,password=******");
        });

        public static ConnectionMultiplexer Connection
        {
            get { return lazyConnection.Value; }
        }

        //public ActionResult Index()
        //{
        //    List<string> newList = new List<string>();
        //    IDatabase cache = Connection.GetDatabase();

        //    var itemKey = "key1";
        //    string itemValue= cache.StringGet(itemKey);
        //    if (itemValue == null)
        //    {
        //        itemValue = "value from my database which is cached";
        //        cache.StringSet(itemKey, itemValue);
        //    }

        //    ViewBag.cacheValue = "We Received Cache : " + cache.StringGet(itemKey); 
        //    return View();
        //}

        public ActionResult myData()
        {
            List<string> newList = new List<string>();
            IDatabase cache = Connection.GetDatabase();

            Stopwatch watch = new Stopwatch();
            watch.Start();

            //cache.KeyDelete("KeyNameWhichYouWantToDelete"); //To delete existing key
            string itemKey = "Key4";
            string itemValue = cache.StringGet(itemKey);
            if (itemValue == null)
            {
                //Here I store simple string in variable Result, You can store your data from database
                //var result = (from data in DbContext.TableName select data).ToList(); //select query on your sample data
                var result = "mySampleData";

                DateTimeOffset fDateTiem = DateTime.Now.AddDays(10);
                var expiration = fDateTiem.Subtract(DateTimeOffset.Now);
                var serializedObject = JsonConvert.SerializeObject(result);
                cache.StringSet(itemKey, serializedObject, expiration);
            }

            var NewObj = cache.StringGet(itemKey);

            //var Deserialize = JsonConvert.DeserializeObject<List<TableName>>(NewObj); //If you Cheching database object then you have to deserialize this
            watch.Stop();
            ViewBag.TimeSpan = watch.ElapsedMilliseconds;

            ViewBag.cacheValue = NewObj;
            return View();
        }

        

    }
}
